using System;
using Gtk;

public partial class MainWindow: Gtk.Window
{	
	public int operacion = 0;     //que se quiere hacer (+ = 1, - = 2, * = 3, / = 4) 
	public bool pendiente = false;    // si se aprieta un operando pasa a true.
	public bool separador_decimal = false;   //si se aprieta el punto pasa a true
	public double primer_numero, segundo_numero, resultado; 
	public MainWindow (): base (Gtk.WindowType.Toplevel)
	{
		Build ();
	}

	protected void OnDeleteEvent (object sender, DeleteEventArgs a)
	{
		Application.Quit ();
		a.RetVal = true;
	}

	protected void B1_clicked (object sender, EventArgs e)
	{
		if(pendiente)
		{
			primer_numero = double.Parse(cajatexto.Text);
			pendiente = false;
			cajatexto.Text = "";
		}
		cajatexto.Text = cajatexto.Text + (sender as Button).Label; 
	}
	

	protected void Operation_clicked (object sender, EventArgs e)
	{
		if (cajatexto.Text != "")
		{
			pendiente = true;
			if ((sender as Button).Name == "BMAS") operacion = 1;
			if ((sender as Button).Name == "BMENOS") operacion = 2;
			if ((sender as Button).Name == "BMULTI") operacion = 3;
			if ((sender as Button).Name == "BDIVIDIR") operacion = 4;
			separador_decimal = false;
		} 
	}

	protected void punto_clicked (object sender, EventArgs e)
	{
		if (!separador_decimal)
		{
			if(pendiente)
			{
				primer_numero = double.Parse(cajatexto.Text);
				pendiente = false;
				cajatexto.Text = "0,";
			}
			else
			{
				if (cajatexto.Text == "")  
					cajatexto.Text = "0,";
				else                       
					cajatexto.Text = cajatexto.Text + ",";
			}
			separador_decimal = true;
		} 
	}




	protected void cero_clicked (object sender, EventArgs e)
	{
		if(pendiente)
		{
			primer_numero = double.Parse(cajatexto.Text);
			pendiente = false;
			cajatexto.Text = "0,";
			separador_decimal = true;
		}
		else
		{
			if (cajatexto.Text == "")  
			{
				cajatexto.Text = "0,";
				separador_decimal = true;
			}
			else                       
				cajatexto.Text = cajatexto.Text + "0";
		} 
	}


	protected void igual_clicked (object sender, EventArgs e)
	{
		if ( (operacion >=1) && (operacion <=4) )
		{
			segundo_numero = double.Parse(cajatexto.Text);
			switch(operacion)
			{
				case 1: resultado = primer_numero + segundo_numero; break;
				case 2: resultado = primer_numero - segundo_numero; break;
				case 3: resultado = primer_numero * segundo_numero; break;
				case 4: resultado = primer_numero / segundo_numero; break;
			}
			cajatexto.Text = Convert.ToString(resultado);
			separador_decimal = false;
		} 
	}
	protected virtual void cajatexto_KeyPressEvent (object o, Gtk.KeyPressEventArgs args)
	{
		string misDigitos = "0123456789";
		if (Array.IndexOf (misDigitos.ToCharArray (), Convert.ToChar (args.Event.Key)) == -1 && args.Event.Key != Gdk.Key.BackSpace) {
			args.RetVal = true;
		} 
	}
}
